package org.example;

import org.example.types.HumiditySensorEvent;
import org.example.types.SensorEvent;
import org.example.types.TemperatureSensorEvent;
import org.example.utils.Utils;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;

public class CenterService implements SensorListener{
    private final Map<Class<? extends SensorEvent>, BiConsumer<String, String>> sensor2supportedProcessors;

    public CenterService() {
        this.sensor2supportedProcessors = new HashMap<>();
        // create processors
        sensor2supportedProcessors.put(TemperatureSensorEvent.class, this::processTemperatureValue);
        sensor2supportedProcessors.put(HumiditySensorEvent.class, this::processHumidityValue);
    }

    @Override
    public void onSensorDataReceived(SensorEvent event) {
        BiConsumer<String, String> valueConsumer = sensor2supportedProcessors.get(event.getClass());
        if (valueConsumer == null) {
            System.out.printf("CenterService.onSensorDataReceived() | Unsupported sensor event type received -> event=%s%n", event);
            return;
        }
        valueConsumer.accept(event.id(), event.value());
    }

    private void processTemperatureValue(String id, String value) {
        int temp = Utils.parseInt(value, Integer.MIN_VALUE);
        if (temp < -100 || temp > 100) {
            System.out.printf("CenterService.processTemperatureValue() | Invalid temperature value, please check sensor %s -> value=%s %n", id, value);
            return;
        }
        if (temp  >= 35) {
            System.out.printf("CenterService.processTemperatureValue() | Warning: High temperature detected on sensor %s -> (temperature >= 35) = %d %n", id, temp);
        }
    }

    private void processHumidityValue(String id, String value) {
        int humidity = Utils.parseInt(value, Integer.MIN_VALUE);
        if (humidity < 0 || humidity > 100) {
            System.out.printf("CenterService.processHumidityValue() | Invalid humidity value, please check sensor %s -> value=%s %n", id, value);
            return;
        }
        if (humidity  >= 50) {
            System.out.printf("CenterService.processHumidityValue() | Warning: High humidity on sensor %s detected -> (humidity >= 50) = %d %n", id, humidity);
        }
    }
}
