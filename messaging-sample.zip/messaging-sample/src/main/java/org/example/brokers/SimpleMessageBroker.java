package org.example.brokers;

import org.example.types.SensorEvent;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

public class SimpleMessageBroker {
    private final LinkedBlockingQueue<SensorEvent> queue;
    private final AtomicBoolean isRunning;

    public SimpleMessageBroker(int capacity) {
        this.queue = new LinkedBlockingQueue<>(capacity);
        this.isRunning = new AtomicBoolean(true);
    }

    public void publish(SensorEvent sensorEvent) {
        if (queue.offer(sensorEvent)) {
            return;
        }
        System.err.printf("SimpleMessageBroker.publish() | Message dropped due to full queue -> message=%s %n", sensorEvent.value());
    }

    public void consume(Consumer<SensorEvent> handler) throws InterruptedException {
        while (isRunning.get()) {
            SensorEvent message = queue.poll(1, TimeUnit.SECONDS);
            if (message == null) {
                continue;
            }
            handler.accept(message);
        }

        SensorEvent remaining;
        while ((remaining = queue.poll()) != null) {
            handler.accept(remaining);
        }
    }

    public void stop() {
        isRunning.set(false);
    }
}
