package org.example;

import org.example.types.SensorEvent;

public interface SensorListener {
    void onSensorDataReceived(SensorEvent event);
}
