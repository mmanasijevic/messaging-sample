package org.example;

import org.example.receivers.UDPReceiverValueBased;
import org.example.types.HumiditySensorEvent;
import org.example.types.SensorEvent;
import org.example.types.TemperatureSensorEvent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainListeners {
    public static void main(String[] args) {
        CenterService centerService = new CenterService();

        UDPReceiverValueBased temperatureSensorReceiver = new UDPReceiverValueBased("TemperatureSensorReceiver", 3344, 1024) {
            @Override
            public SensorEvent createEvent(String message) {
                IdValue idValue = getValueBasedMessage(message);
                return idValue != null ? new TemperatureSensorEvent(idValue.id(), idValue.value()) : null;
            }
        };
        temperatureSensorReceiver.registerSensorListener(centerService);

        UDPReceiverValueBased humiditySensorReceiver = new UDPReceiverValueBased("HumiditySensorReceiver", 3355, 1024) {
            @Override
            public SensorEvent createEvent(String message) {
                IdValue idValue = getValueBasedMessage(message);
                return idValue != null ? new HumiditySensorEvent(idValue.id(), idValue.value()) : null;
            }
        };
        humiditySensorReceiver.registerSensorListener(centerService);

        try (ExecutorService executorService = Executors.newFixedThreadPool(2)) {
            executorService.submit(temperatureSensorReceiver);
            executorService.submit(humiditySensorReceiver);

            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                System.out.println("Main | Shutdown triggered, stopping receivers...");
                temperatureSensorReceiver.stop();
                humiditySensorReceiver.stop();
                executorService.shutdown();
                System.out.println("Main | Shoutdown finished.");
            }));
            Thread.currentThread().join(); // block main thread until shutdown hook is activated.
        } catch (InterruptedException ex) {
            System.err.printf("Main | Main thread interrupted -> exception=%s %n", ex.getMessage());
            Thread.currentThread().interrupt();
        }
    }
}