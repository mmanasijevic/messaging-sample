package org.example.types;

public interface SensorEvent {
    String id();
    String value();
}
