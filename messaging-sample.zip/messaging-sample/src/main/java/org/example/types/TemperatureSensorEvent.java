package org.example.types;

public record TemperatureSensorEvent (String id, String value) implements SensorEvent {
}
