package org.example.types;

public record HumiditySensorEvent(String id, String value) implements SensorEvent {
}
