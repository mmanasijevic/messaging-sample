package org.example.utils;

public final class Utils {
    private Utils () {

    }

    public static boolean isEmptyString (String str) {
        return str == null || str.trim().isEmpty();
    }

    public static int parseInt (String str, int def) {
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException ex) {
            return def;
        }
    }
}
