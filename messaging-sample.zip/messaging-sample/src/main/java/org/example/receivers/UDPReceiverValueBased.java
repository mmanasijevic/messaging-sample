package org.example.receivers;

import org.example.utils.Utils;

import java.util.Map;

public abstract class UDPReceiverValueBased extends UDPReceiver {

    public UDPReceiverValueBased(String name, int port, int bufferSize) {
        super(name, port, bufferSize);
    }

    public IdValue getValueBasedMessage(String message) {
        Map<String, String> key2value = parseMessage(message);
        String sensorId = key2value.get("sensor_id");
        String value = key2value.get("value");
        if (Utils.isEmptyString(sensorId) || Utils.isEmptyString(value)) {
            System.out.printf("TemperatureSensorReceiver.createEvent() | Invalid sensor data received, no value -> data=%s %n", message);
            return null;
        }
        return new IdValue(sensorId, value);
    }

    public record IdValue(String id, String value) {
    }
}
