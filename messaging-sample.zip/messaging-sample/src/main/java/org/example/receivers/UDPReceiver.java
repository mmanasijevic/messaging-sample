package org.example.receivers;

import org.example.SensorListener;
import org.example.utils.Utils;
import org.example.types.SensorEvent;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public abstract class UDPReceiver implements Runnable {
    private final AtomicReference<DatagramSocket> socketReference;
    private final AtomicBoolean isRunning;
    private final String name;
    private final int port;
    private final int bufferSize;

    private final Set<SensorListener> sensorListeners;

    private final Object lock = new Object();

    public abstract SensorEvent createEvent (String message);

    public UDPReceiver(String name, int port, int bufferSize) {
        this.name = name;
        this.port = port;
        this.bufferSize = bufferSize;
        this.socketReference = new AtomicReference<>();
        this.isRunning = new AtomicBoolean(false);

        this.sensorListeners = new HashSet<>();
    }

    public Map<String, String> parseMessage(String message) {
        if (Utils.isEmptyString(message)) {
            System.out.printf("CenterService.onSensorDataReceived() | Invalid sensor data received -> data=%s %n", message);
            return Collections.emptyMap();
        }
        Map<String, String> name2value = new HashMap<>();
        String[] messageTokens = message.split(";");
        for (String nameValueStr : messageTokens) {
            String[] nameValue = nameValueStr.split("=");
            if (nameValue.length != 2 || Utils.isEmptyString(nameValue[0]) || Utils.isEmptyString(nameValue[1])) {
                System.out.printf("CenterService.onSensorDataReceived() | Invalid sensor data received -> data=%s %n", nameValueStr);
                continue;
            }
            name2value.put(nameValue[0], nameValue[1]);
        }
        return name2value;
    }

    public void stop() {
        isRunning.set(false);
        closeSocket();
    }

    @Override
    public void run() {
        try {
            isRunning.set(true);
            System.out.printf("UDPReceiver.run() | Started receiver name=%s, port=%s %n", name, port);
            InetAddress loopbackAddress = InetAddress.getByName("127.0.0.1");
            try (DatagramSocket socket = new java.net.DatagramSocket(port, loopbackAddress)) {
                socketReference.set(socket);
                socket.setSoTimeout(1000);
                byte[] buffer = new byte[bufferSize];
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                while (isRunning.get()) {
                    try {
                        socket.receive(packet);
                        String message = new String(packet.getData(), 0, packet.getLength());
                        SensorEvent sensorEvent = createEvent(message);
                        if (sensorEvent != null) {
                            notifySensorListeners(sensorEvent);
                        }
                    } catch (SocketTimeoutException ignored) {
                        // normal when no sender
                    }
                }
                System.out.printf("UDPReceiver.run() | Receiver stopped -> name=%s %n", name);
            }
        } catch (Exception ex) {
            System.err.printf("UDPReceiver.run() | Receiver stopped because exception-> name=%s, exception=%s %n", name, ex.getMessage());
        } finally {
            unregisterListeners();
            isRunning.set(false);
        }
    }

    private void notifySensorListeners(SensorEvent event) {
        synchronized (lock) {
            for (SensorListener listener : sensorListeners) {
                listener.onSensorDataReceived(event);
            }
        }
    }

    public void registerSensorListener(SensorListener listener) {
        synchronized (lock) {
            sensorListeners.add(listener);
        }
    }

    public void unregisterListeners() {
        synchronized (lock) {
            sensorListeners.clear();
        }
    }

    private void closeSocket() {
        DatagramSocket socket = socketReference.getAndSet(null);
        if (socket == null || socket.isClosed()) {
            return;
        }
        socket.close();
    }
}
